# The Hollow — TeaHack Horror Game

A browser-based, top-down horror prototype featuring a procedurally generated maze, chasing enemies, boss encounters from level 3, pickups, score, sound effects, local save/resume, and room-based online player visibility.

## Requirements

- Node.js 18 or newer
- A modern desktop or mobile browser

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000. For co-op, open the page in another browser/device and enter the same room code. For devices on the same Wi-Fi, use the host computer's LAN IP, e.g. `http://192.168.1.20:3000`.

## Controls

- WASD / arrow keys: move
- E: interact with exit / use a flare
- Space: use medkit
- M: toggle sound
- Esc: pause

## Gameplay

- Walk over items to collect medkits, flares, keys and relics.
- Relics grant score. Exits grant a sector-clear bonus.
- A flare defeats nearby stalkers and damages the Warden boss.
- Starting at sector 3, a Warden appears; defeat it to unlock the exit.
- The browser saves progress in localStorage. “Resume Save” restores progression and inventory.

## Online multiplayer notes

Socket.IO synchronizes room membership and player positions. Use the same room code to see other survivors. This is a playable multiplayer prototype, not a competitive authoritative game server: movement, enemies, inventory, damage and scoring are currently simulated client-side. Do not expose it publicly as a trusted game economy without server-authoritative simulation, input validation, authentication, persistent storage, abuse controls and deployment hardening.

## Configuration

Set `PORT` to change the listening port. `CORS_ORIGIN` can be a comma-separated allowlist for cross-origin Socket.IO clients; for public deployment, configure an explicit origin rather than the permissive development default.

## Project structure

- `server.js` — Express + Socket.IO room relay
- `public/index.html` — UI, canvas renderer, maze generation, gameplay, sound and save system


## iPhone and Android

The game now includes touch movement and action buttons and PWA metadata.

### Play on a phone

1. Run the Node server on a computer or deploy it to a Node.js host with HTTPS.
2. Connect the phone to the same Wi-Fi (for local play) and open the server's LAN address, such as `http://192.168.1.20:3000`, or open your deployed HTTPS URL.
3. Enter the same room code as friends to see each other in multiplayer.

### Install on the home screen

- **iPhone/iPad:** Open the deployed HTTPS URL in Safari → Share → Add to Home Screen.
- **Android:** Open the deployed HTTPS URL in Chrome → menu → Install app / Add to Home screen.

For reliable PWA installation, deploy over HTTPS. `localhost` is treated as secure for development, but a phone connecting to another computer over a LAN IP generally needs HTTPS for service-worker/PWA features. Touch gameplay itself can still run over the local network.

This remains a browser/PWA game, not a native App Store or Google Play package. A native wrapper (for example Capacitor) and store signing/review are separate steps.
